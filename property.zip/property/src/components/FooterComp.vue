<template>
    <div style="background-color: #F8F8F8;border-top: 1px solid rgb(196, 192, 192);padding:30px 2px;margin-top: 20px;">
        <footer>
            <div class="footerimg">
                <img src="@/assets/Images/loooo.jpg" class="footer_image">
                <nav class="navigation3">
                    <ul>
                        <li><a href="#"> About us</a> </li>
                        <li><a href="#">Terms & Conditions</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Client Login</a></li>
                        <li><a href="#">Careers</a></li>
                        <li><a href="#">Agent Hub</a></li>
                    </ul>
                </nav>
            </div>
        </footer>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
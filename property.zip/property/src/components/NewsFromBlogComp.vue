<template>
  <div class="klj" style="min-width: 100%">
    <div class="div_height">
      <div style="padding-left: 20px">
        <h5 style="color: white; margin-top: 10px">
          Agent Hub: Grow your audience, boost your brand
        </h5>
        <p style="color: white">
          For real estate agents who want to make the most out of their presence
          on Property Finder
        </p>
        <router-link to="/properties">
          <button
            style="
              padding: 10px;
              border-radius: 4px;
              border: none;
              color: #247da9;
            "
          >
            <b> search more listings </b>
          </button>
        </router-link>
      </div>
      <div style="width: 40%" class="scf">
        <img
          style="border-radius: 4px"
          src="https://www.propertyfinder.ae/dist/desktop/assets/49997d5309.agenthub-banner-image.jpg"
          width="100%"
          height="170"
        />
      </div>
    </div>
    <hr style="margin-top: 15px" />
    <div style="display: flex; background-color: #fcfcfc">
      <div style="width: 15%; font-size: 14px">
        <p><b>15 Mar </b></p>
      </div>
      <a href="#" class="date_links" style="width: 85%">
        <div>
          <p>Best Landscaping Companies in Dubai</p>
        </div>
      </a>
    </div>
    <div style="display: flex">
      <div style="width: 15%; font-size: 14px">
        <p><b>10 Feb</b></p>
      </div>
      <a href="#" class="date_links" style="width: 85%">
        <div>
          <p>Best Hidden Gems in Dubai</p>
        </div>
      </a>
    </div>
    <div style="display: flex; background-color: #fcfcfc">
      <div style="width: 15%; font-size: 14px">
        <p><b>09 Feb </b></p>
      </div>
      <a href="#" class="date_links" style="width: 85%">
        <div>
          <p>All You Need to Know About Smart Dubai</p>
        </div>
      </a>
    </div>
    <div style="display: flex">
      <div style="width: 15%; font-size: 14px">
        <p><b>02 Feb </b></p>
      </div>
      <a href="#" class="date_links" style="width: 85%">
        <div>
          <p>Best Gyms in Abu Dhabi</p>
        </div>
      </a>
    </div>

    <div style="display: flex; background-color: #fcfcfc">
      <div style="width: 15%; font-size: 14px">
        <p><b>30 Jan </b></p>
      </div>
      <a href="#" class="date_links" style="width: 85%">
        <div>
          <p>District 2020: The Future of Sustainability in Dubai</p>
        </div>
      </a>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style></style>

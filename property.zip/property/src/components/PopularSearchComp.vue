<template>
  <div class="popularsearch">
    <div class="popular-search-div">
      <p>POPULAR SEARCHES</p>
      <a href="#" class="popular_links"><p>Properties for rent in UAE</p></a>
      <a href="#" class="popular_links"><p>Properties for sale in UAE</p></a>
      <a href="#" class="popular_links"><p>Apartments for rent in UAE</p></a>
      <a href="#" class="popular_links"><p>Apartments for rent in Dubai</p></a>
      <a href="#" class="popular_links"><p>Properties for sale in Dubai</p></a>
      <a href="#" class="popular_links"><p>Villas for sale in Dubai</p></a>
      <a href="#" class="popular_links"><p>Dubai Real Estate</p></a>
    </div>
    <div class="popular-search-div">
      <p>POPULAR SEARCHES</p>
      <a href="#" class="popular_links"><p>Apartments for rent in Dubai</p></a>
      <a href="#" class="popular_links"><p>Apartments for rent Abu Dhabi</p></a>
      <a href="#" class="popular_links"><p>Villas for rent in Dubai</p></a>
      <a href="#" class="popular_links"><p>House for rent Abu Dhabi</p></a>
      <a href="#" class="popular_links"><p>Apartments for sale in Dubai</p></a>
      <a href="#" class="popular_links"
        ><p>Apartments for sale in Abu Dhabi</p></a
      >
      <a href="#" class="popular_links"><p>Flat for rent Sharjah</p></a>
    </div>
    <div class="popular-search-div">
      <p>POPULAR SEARCHES</p>
      <a href="#" class="popular_links"
        ><p>Apartments for rent in Dubai Marina</p></a
      >
      <a href="#" class="popular_links"
        ><p>Apartments for sale in Dubai Marina</p></a
      >
      <a href="#" class="popular_links"><p>Villa for rent in Sharjah</p></a>
      <a href="#" class="popular_links"><p>Villa for sale in Dubai</p></a>
      <a href="#" class="popular_links"><p>Flat for rent in Ajman</p></a>
      <a href="#" class="popular_links"><p>Studio for rent in Abu Dhabi</p></a>
      <a href="#" class="popular_links"><p>Villa for rent in Ajman</p></a>
    </div>
    <div class="popular-search-div">
      <p>POPULAR SEARCHES</p>
      <a href="#" class="popular_links"><p>Villa for rent in Abu Dhabi</p></a>
      <a href="#" class="popular_links"><p>Shop for rent in Dubai</p></a>
      <a href="#" class="popular_links"><p>Villas for sale in Ajman</p></a>
      <a href="#" class="popular_links"><p>Studio for rent in Sharjah</p></a>
      <a href="#" class="popular_links"
        ><p>1 Bedroom Apartment for rent in Dubai</p></a
      >
      <a href="#" class="popular_links"
        ><p>Property for rent in Abu Dhabi</p></a
      >
      <a href="#" class="popular_links"
        ><p>Commercial properties for sale</p></a
      >
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style></style>

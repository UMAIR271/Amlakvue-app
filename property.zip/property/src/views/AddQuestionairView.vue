<template>
  <div class="container-fluid">
    <div class="tab-content">
      <div
        class="tab-pane fade show active"
        id="quiz"
        role="tabpanel"
        aria-labelledby="quiz-tab"
      >
        <div class="card border-info mb-4">
          <div
            class="d-flex justify-content-between align-items-center card-header bg-info text-white"
            id="h1"
          >
            <span>Question 1</span>
          </div>
          <div id="q1" class="collapse show" aria-labelledby="h1">
            <div class="card-body">
              <p>Philology is the</p>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r1"
                  value="r1"
                />
                <label class="form-check-label" for="q1_r1">
                  study of bones
                </label>
              </div>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r2"
                  value="r2"
                />
                <label class="form-check-label" for="q1_r2">
                  study of muscles
                </label>
              </div>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r3"
                  value="r3"
                />
                <label class="form-check-label" for="q1_r3">
                  study of architecture
                </label>
              </div>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r4"
                  value="r4"
                />
                <label class="form-check-label" for="q1_r4">
                  science of languages
                </label>
              </div>
            </div>
          </div>
        </div>
        <div class="card border-info mb-4">
          <div
            class="d-flex justify-content-between align-items-center card-header bg-info text-white"
            id="h1"
          >
            <span>Question 2</span>
          </div>
          <div id="q1" class="collapse show" aria-labelledby="h1">
            <div class="card-body">
              <p>Philology is the</p>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r1"
                  value="r1"
                />
                <label class="form-check-label" for="q1_r1">
                  study of bones
                </label>
              </div>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r2"
                  value="r2"
                />
                <label class="form-check-label" for="q1_r2">
                  study of muscles
                </label>
              </div>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r3"
                  value="r3"
                />
                <label class="form-check-label" for="q1_r3">
                  study of architecture
                </label>
              </div>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r4"
                  value="r4"
                />
                <label class="form-check-label" for="q1_r4">
                  science of languages
                </label>
              </div>
            </div>
          </div>
        </div>
        <div class="card border-info mb-4">
          <div
            class="d-flex justify-content-between align-items-center card-header bg-info text-white"
            id="h1"
          >
            <span>Question 3</span>
          </div>
          <div id="q1" class="collapse show" aria-labelledby="h1">
            <div class="card-body">
              <p>Philology is the</p>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r1"
                  value="r1"
                />
                <label class="form-check-label" for="q1_r1">
                  study of bones
                </label>
              </div>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r2"
                  value="r2"
                />
                <label class="form-check-label" for="q1_r2">
                  study of muscles
                </label>
              </div>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r3"
                  value="r3"
                />
                <label class="form-check-label" for="q1_r3">
                  study of architecture
                </label>
              </div>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r4"
                  value="r4"
                />
                <label class="form-check-label" for="q1_r4">
                  science of languages
                </label>
              </div>
            </div>
          </div>
        </div>
        <div class="card border-info mb-4">
          <div
            class="d-flex justify-content-between align-items-center card-header bg-info text-white"
            id="h1"
          >
            <span>Question 4</span>
          </div>
          <div id="q1" class="collapse show" aria-labelledby="h1">
            <div class="card-body">
              <p>Philology is the</p>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r1"
                  value="r1"
                />
                <label class="form-check-label" for="q1_r1">
                  study of bones
                </label>
              </div>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r2"
                  value="r2"
                />
                <label class="form-check-label" for="q1_r2">
                  study of muscles
                </label>
              </div>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r3"
                  value="r3"
                />
                <label class="form-check-label" for="q1_r3">
                  study of architecture
                </label>
              </div>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r4"
                  value="r4"
                />
                <label class="form-check-label" for="q1_r4">
                  science of languages
                </label>
              </div>
            </div>
          </div>
        </div>
        <div class="card border-info mb-4">
          <div
            class="d-flex justify-content-between align-items-center card-header bg-info text-white"
            id="h1"
          >
            <span>Question 5</span>
          </div>
          <div id="q1" class="collapse show" aria-labelledby="h1">
            <div class="card-body">
              <p>Philology is the</p>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r1"
                  value="r1"
                />
                <label class="form-check-label" for="q1_r1">
                  study of bones
                </label>
              </div>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r2"
                  value="r2"
                />
                <label class="form-check-label" for="q1_r2">
                  study of muscles
                </label>
              </div>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r3"
                  value="r3"
                />
                <label class="form-check-label" for="q1_r3">
                  study of architecture
                </label>
              </div>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r4"
                  value="r4"
                />
                <label class="form-check-label" for="q1_r4">
                  science of languages
                </label>
              </div>
            </div>
          </div>
        </div>
        <div class="card border-info mb-4">
          <div
            class="d-flex justify-content-between align-items-center card-header bg-info text-white"
            id="h1"
          >
            <span>Question 6</span>
          </div>
          <div id="q1" class="collapse show" aria-labelledby="h1">
            <div class="card-body">
              <p>Philology is the</p>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r1"
                  value="r1"
                />
                <label class="form-check-label" for="q1_r1">
                  study of bones
                </label>
              </div>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r2"
                  value="r2"
                />
                <label class="form-check-label" for="q1_r2">
                  study of muscles
                </label>
              </div>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r3"
                  value="r3"
                />
                <label class="form-check-label" for="q1_r3">
                  study of architecture
                </label>
              </div>

              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="q1"
                  id="q1_r4"
                  value="r4"
                />
                <label class="form-check-label" for="q1_r4">
                  science of languages
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

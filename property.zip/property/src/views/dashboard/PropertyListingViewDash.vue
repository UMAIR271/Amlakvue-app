<template>
  <div>
      <div class="card">
          <h5 class="card-header">Property Listings</h5>
          <div class="card-body">
              <table class="table">
                  <thead>
                      <tr>
                          <th scope="col">#</th>
                          <th scope="col">Title</th>
                          <th scope="col">Description</th>
                          <th scope="col">View</th>
                          <th scope="col">Edit</th>
                          <th scope="col">Pause</th>
                          <th scope="col">Approve</th>
                          <th scope="col">Delete</th>

                      </tr>
                  </thead>
                  <tbody>
                      <tr>
                          <th scope="row">1</th>
                          <td>Mark Zucv wW</td>
                          <td>Otto Wanchiani ka matter</td>
                          <td><button>view</button></td>
                          <td><button>edit</button></td>
                          <td><button>pause</button></td>
                          <td><button>approve</button></td>
                          <td><button>delete</button></td>
                      </tr>
                      <tr>
                          <th scope="row">2</th>
                          <td>Mark Zucv wW</td>
                          <td>Otto Wanchiani ka matter</td>
                          <td><button>view</button></td>
                          <td><button>edit</button></td>
                          <td><button>pause</button></td>
                          <td><button>approve</button></td>
                          <td><button>delete</button></td>
                      </tr>
                      <tr>
                          <th scope="row">3</th>
                          <td>Mark Zucv wW</td>
                          <td>Otto Wanchiani ka matter</td>
                          <td><button>view</button></td>
                          <td><button>edit</button></td>
                          <td><button>pause</button></td>
                          <td><button>approve</button></td>
                          <td><button>delete</button></td>
                      </tr>
                      <tr>
                          <th scope="row">4</th>
                          <td>Mark Zucv wW</td>
                          <td>Otto Wanchiani ka matter</td>
                          <td><button>view</button></td>
                          <td><button>edit</button></td>
                          <td><button>pause</button></td>
                          <td><button>approve</button></td>
                          <td><button>delete</button></td>
                      </tr>
                      <tr>
                          <th scope="row">5</th>
                          <td>Mark Zucv wW</td>
                          <td>Otto Wanchiani ka matter</td>
                          <td><button>view</button></td>
                          <td><button>edit</button></td>
                          <td><button>pause</button></td>
                          <td><button>approve</button></td>
                          <td><button>delete</button></td>
                      </tr>
                      <tr>
                          <th scope="row">6</th>
                          <td>Mark Zucv wW</td>
                          <td>Otto Wanchiani ka matter</td>
                          <td><button>view</button></td>
                          <td><button>edit</button></td>
                          <td><button>pause</button></td>
                          <td><button>approve</button></td>
                          <td><button>delete</button></td>
                      </tr>
                      
                  </tbody>
              </table>
          </div>
      </div>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
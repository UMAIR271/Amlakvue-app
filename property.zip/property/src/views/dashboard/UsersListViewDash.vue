<template>
  <div>
      <div class="card">
          <h5 class="card-header">List of Users</h5>
          <div class="card-body">
              <table class="table">
                  <thead>
                      <tr>
                          <th scope="col">#</th>
                          <th scope="col">First Name</th>
                          <th scope="col">Last Name</th>
                          <th scope="col">Restrict</th>
                          <th scope="col">Delete</th>

                      </tr>
                  </thead>
                  <tbody>
                      <tr>
                          <th scope="row">1</th>
                          <td>Mark</td>
                          <td>Otto</td>
                          <td><button>restrict</button></td>
                          <td><button>remove</button></td>
                      </tr>
                      <tr>
                          <th scope="row">2</th>
                          <td>Mark</td>
                          <td>Otto</td>
                          <td><button>restrict</button></td>
                          <td><button>remove</button></td>
                      </tr>
                      <tr>
                          <th scope="row">3</th>
                          <td>Mark</td>
                          <td>Otto</td>
                          <td><button>restrict</button></td>
                          <td><button>remove</button></td>
                      </tr>
                      <tr>
                          <th scope="row">4</th>
                          <td>Mark</td>
                          <td>Otto</td>
                          <td><button>restrict</button></td>
                          <td><button>remove</button></td>
                      </tr>
                      <tr>
                          <th scope="row">5</th>
                          <td>Mark</td>
                          <td>Otto</td>
                          <td><button>restrict</button></td>
                          <td><button>remove</button></td>
                      </tr>
                      <tr>
                          <th scope="row">6</th>
                          <td>Mark</td>
                          <td>Otto</td>
                          <td><button>restrict</button></td>
                          <td><button>remove</button></td>
                      </tr>
                      
                  </tbody>
              </table>
          </div>
      </div>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>